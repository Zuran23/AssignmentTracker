Project Requirements: Password Validator

Pseudocode:

Print: “enter your password”
Scanner

Check input for character length (if <8, print “Password does not meet the required conditions”)

Check password for digit (0-9) (if none, print “Password does not meet the required conditions”)

Check password for special character (!@#$%^&*()_+-=[]{};:'"|,.<>?/) (if none, print “Password does not meet the required conditions”)

Else print "password is strong”
